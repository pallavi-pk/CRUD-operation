package com.leadToRevenue.Catalogue;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.leadToRevenue.Catalogue.entity.Product;


public interface ProductRepo extends JpaRepository<Product, Long>{
	
	List<Product> findByNameContaining(String name);

    List<Product> findByCategoriesContaining(String category);

    List<Product> findByRatingsRatingGreaterThanEqual(int minRating);

}

