package com.leadToRevenue.Catalogue.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.leadToRevenue.Catalogue.ProductRepo;
import com.leadToRevenue.Catalogue.dao.ProductDao;
import com.leadToRevenue.Catalogue.entity.Product;


@Service
public class ProductService {
	@Autowired
	ProductDao productdao;

//1	
	public String addProduct(Product product) {

		String msg = productdao.addProduct(product);

		return msg;
	}

//2	
	public String updateProduct(Product product) {

		String msg = productdao.updateProduct(product);
		return msg;
	}

//3	
	public String deleteProduct(int id) {

		String msg = productdao.deleteProduct(id);
		return msg;
	}

//4	
	public List<Product> getAllProduct() {

		List<Product> list = productdao.getAllProduct();
		return list;
	}
	
	@Autowired
    private ProductRepo productRepository;

    // Method to find products by name
    public List<Product> findProductsByName(String name) {
        return productRepository.findByNameContaining(name);
    }

    // Method to find products by category
    public List<Product> findProductsByCategory(String category) {
        return productRepository.findByCategoriesContaining(category);
    }

    // Method to find products by minimum rating
    public List<Product> findProductsByRating(int minRating) {
        return productRepository.findByRatingsRatingGreaterThanEqual(minRating);
    }

}
