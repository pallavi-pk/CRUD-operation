package com.leadToRevenue.Catalogue.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.leadToRevenue.Catalogue.entity.Product;
import com.leadToRevenue.Catalogue.entity.Rating;

@Repository
public class ProductDao {

	@Autowired
	SessionFactory sf;

//adding product	
	public String addProduct(Product product) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();

		// Ensure that the association between Product and Rating is properly set
		for (Rating rating : product.getRatings()) {
			rating.setProduct(product);
		}

		session.save(product);
		tr.commit();
		session.close();

		return "inserted";
	}

//updating product	
	public String updateProduct(Product product) {

		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.update(product);
		tr.commit();
		session.close();

		return "updated";
	}

//delete product	
	public String deleteProduct(int id) {

		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Product product = session.load(Product.class, id);
		session.delete(product);
		tr.commit();
		session.close();
		return "deleted";
	}

//retrieve products	
	public List<Product> getAllProduct() {

		Session session = sf.openSession();
		List<Product> al = session.createQuery("from Product").list();
		return al;

	}

}
