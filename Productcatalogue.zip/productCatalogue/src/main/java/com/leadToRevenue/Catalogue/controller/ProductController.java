package com.leadToRevenue.Catalogue.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.leadToRevenue.Catalogue.entity.Product;
import com.leadToRevenue.Catalogue.service.ProductService;


@RestController
@RequestMapping("/api")
public class ProductController {
	@Autowired
	ProductService productService;

	
//1	
	@PostMapping("/add")
	public String addProduct(@RequestBody Product product) {

		productService.addProduct(product);

		return "inserted";

	}

//2	
	@PutMapping("/update")
	public String updateCustomer(@RequestBody Product product) {

		productService.updateProduct(product);
		return "updated";

	}

//3	
	@DeleteMapping("/{id}")
	public String deleteProduct(@PathVariable int id) {

		productService.deleteProduct(id);
		return "deleted";
	}

//4	
	@GetMapping("/getAll")
	public List<Product> getAll() {

		List<Product> list = productService.getAllProduct();
		return list;
	}
	
	

    // Endpoint to filter products by name
    @GetMapping("/filterByName/{name}")
    public List<Product> filterProductsByName(@PathVariable String name) {
        return productService.findProductsByName(name);
    }

    // Endpoint to filter products by category
    @GetMapping("/filterByCategory")
    public List<Product> filterProductsByCategory(@RequestParam String category) {
        return productService.findProductsByCategory(category);
    }

    // Endpoint to filter products by minimum rating
    @GetMapping("/filterByRating")
    public List<Product> filterProductsByRating(@RequestParam int minRating) {
        return productService.findProductsByRating(minRating);
    }

}

